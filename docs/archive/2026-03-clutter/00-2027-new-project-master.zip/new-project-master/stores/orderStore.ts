import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import { CartItem } from '@/types';

export interface ShipmentEvent {
    id: string;
    details: string;
    location: string;
    date: string;
    status: 'ordered' | 'shipped' | 'in-transit' | 'out-for-delivery' | 'delivered';
}

export interface Order {
    id: string;
    items: CartItem[];
    total: number;
    status: 'pending' | 'processing' | 'shipped' | 'delivered';
    date: string;
    customer: {
        name: string;
        email: string;
    };
    paymentId?: string;
    trackingNumber?: string;
    carrier?: string;
    estimatedDelivery?: string;
    shipmentEvents?: ShipmentEvent[];
}

interface OrderState {
    orders: Order[];
    addOrder: (order: Order) => void;
    updateStatus: (orderId: string, status: Order['status']) => void;
    updateShipment: (orderId: string, trackingNumber: string, carrier: string) => void;
    getOrdersByEmail: (email: string) => Order[];
    getOrderByTracking: (trackingNumber: string) => Order | undefined;
    getAllOrders: () => Order[];
    getRevenue: () => number;
}

export const useOrderStore = create<OrderState>()(
    persist(
        (set, get) => ({
            orders: [],

            addOrder: (order) => set((state) => ({
                orders: [order, ...state.orders]
            })),

            updateStatus: (orderId, status) => set((state) => ({
                orders: state.orders.map(o =>
                    o.id === orderId ? { ...o, status } : o
                )
            })),

            updateShipment: (orderId, trackingNumber, carrier) => set((state) => ({
                orders: state.orders.map(o => {
                    if (o.id === orderId) {
                        return {
                            ...o,
                            status: 'shipped',
                            trackingNumber,
                            carrier,
                            estimatedDelivery: new Date(Date.now() + 3 * 24 * 60 * 60 * 1000).toISOString(), // Mock 3 days out
                            shipmentEvents: [
                                {
                                    id: `evt-${Date.now()}`,
                                    details: 'Order details received',
                                    location: 'Warehouse',
                                    date: new Date().toISOString(),
                                    status: 'ordered'
                                },
                                {
                                    id: `evt-${Date.now() + 1}`,
                                    details: `Shipped via ${carrier}`,
                                    location: 'Distribution Center',
                                    date: new Date().toISOString(),
                                    status: 'shipped'
                                }
                            ]
                        };
                    }
                    return o;
                })
            })),

            getOrdersByEmail: (email) => {
                return get().orders.filter(o => o.customer.email === email);
            },

            getOrderByTracking: (trackingNumber) => {
                return get().orders.find(o => o.trackingNumber === trackingNumber);
            },

            getAllOrders: () => get().orders,

            getRevenue: () => {
                return get().orders.reduce((acc, curr) => acc + curr.total, 0);
            }
        }),
        {
            name: 'nexus-orders-storage',
        }
    )
);
