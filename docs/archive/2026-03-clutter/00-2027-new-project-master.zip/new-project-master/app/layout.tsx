import type { Metadata } from 'next';
import { Inter } from 'next/font/google';
import './globals.css';
import { AiAssistant } from '../components/ai-assistant';
import { Navbar } from '../components/navbar';
import { Footer } from '../components/footer';
import { CartDrawer } from '../components/cart-drawer';
import { PageTransition } from '../components/page-transition';

const inter = Inter({ subsets: ['latin'] });

export const metadata: Metadata = {
    metadataBase: new URL('https://nexus-store.vercel.app'), // Placeholder URL
    title: {
        default: 'NEXUS | The Future of Tech',
        template: '%s | NEXUS'
    },
    description: 'NEXUS is a premium e-commerce destination for next-generation technology, neural interfaces, and quantum computing hardware.',
    openGraph: {
        title: 'NEXUS | The Future of Tech',
        description: 'Experience the next generation of neural interfaces and quantum hardware.',
        url: 'https://nexus-store.vercel.app',
        siteName: 'NEXUS',
        locale: 'en_US',
        type: 'website',
    },
    twitter: {
        card: 'summary_large_image',
        title: 'NEXUS | The Future of Tech',
        description: 'Experience the next generation of neural interfaces and quantum hardware.',
    },
    robots: {
        index: true,
        follow: true,
    }
};

// ... (imports remain)

// ... (metadata remains)

export default function RootLayout({
    children,
}: {
    children: React.ReactNode;
}) {
    return (
        <html lang="en" className="dark" suppressHydrationWarning>
            <body className={inter.className}>
                <Navbar />
                <PageTransition>
                    {children}
                </PageTransition>
                <CartDrawer />
                <Footer />
                <AiAssistant />
            </body>
        </html>
    );
}
